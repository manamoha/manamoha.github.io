---
permalink: /education/
title: "Education"
author_profile: true
---

### B.Sc.
- <img src="/images/UT.png" width="50" alt="University of Tehran" /> **Electrical Engineering**, [University of Tehran](https://ut.ac.ir/), 2021-2025

### Diploma
- <img src="/images/Farzanegan.png" width="50" alt="Farzanegan Amin Highschool (NODET)" /> **Mathematics and Physics**, [Farzanegan Amin Highschool (NODET)](https://www.famin1.ir/portal/index.html), 2018-2021

