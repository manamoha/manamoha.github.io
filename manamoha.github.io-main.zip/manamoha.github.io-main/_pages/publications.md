---
permalink: /publications/
title: "Publications"
author_profile: true
# redirect_from: 
#   - /about/
  # - /about.html
---

- *A. N. Ghameshlou, A. Jafari Rad, M. Mohammadi*, “A note on the domination entropy of graphs,” Journal of Discrete Mathematics and Its Application (Under Review).  

- *A. Ebrahimi, M. Mohammadi*, “Controllability Analysis of Human Protein Interaction Networks to Identify Disease Genes and Drug Targets for Drug Repurposing” (Under Preparation).  

