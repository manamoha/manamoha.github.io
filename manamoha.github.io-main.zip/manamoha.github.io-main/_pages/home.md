---
permalink: /
# title: "Home Page"
author_profile: true
redirect_from: 
  - /home/
--- 
<br>
<br>
<br>
<br>

# Welcome to My Website! 
 Hi, I'm Mana Mohammadi!
I'm an electrical engineering student from the University of Tehran.
I'm particularly passionate about blending signal processing, data analysis, and machine learning to solve biomedical challenges.

